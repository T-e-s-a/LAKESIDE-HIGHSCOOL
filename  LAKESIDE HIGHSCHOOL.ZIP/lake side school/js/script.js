let btn = document.getElementById("btn");
btn.onclick = function(){
alert("Hello This is a website");
}
